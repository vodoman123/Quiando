<p>
	Adding a little javascript to the template,
	you can have a nice mouse-over effect
	when you hover your mouse cursor over poll items.
</p>
