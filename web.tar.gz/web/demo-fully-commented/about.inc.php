<p>
This poll is exactly the same as <span class='doc-kw'>demo-your-first-poll</span> except that the poll files are fully commented.
</p>

<p>
Check out the following three files. They contain important information about customizing polls.
</p>

<p>
	<ul>
		<li>tpl.front.inc.php</li>
		<li>tpl.result.inc.php</li>
		<li>class.inc.php</li>
	</ul>
</p>


