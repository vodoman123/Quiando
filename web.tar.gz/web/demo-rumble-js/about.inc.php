<p>
This demo shows you an example of including an external javascript to poll templates. The poll contains <b>rumble.js</b> javascript that "rumbles" poll options and buttons when you hover the mouse cursor over them. rumble.js is included in the package but you can also download it separately from the author's website ( <a href='http://jackrugile.com/jrumble/' target='_blank'>http://jackrugile.com/jrumble/</a> ).
</p>

