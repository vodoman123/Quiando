<p>
Welcome to Ajax Poll Script!
Here is your first poll!
</p>

<p style='font-size:13px;'>
( Note: To edit this "About" section, edit <span class='doc-kw'>about.inc.php</span>, which you can find in this folder. )
</p>

