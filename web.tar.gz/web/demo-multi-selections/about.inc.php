<p>
	This poll allows users to select more than one options.
</p>

<p>
	To allow users to select more than one option, use the <span class='doc-kw'>checkbox</span> type for input tags like shown below:

	<pre class='doc-code'>&lt;input type="checkbox" ... /&gt;	</pre>
</p>
