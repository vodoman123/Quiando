<?php

//STEP 1 Connect To Database
$connect = mysql_connect("localhost","root","root");
if (!$connect)
{
die("MySQL could not connect!");
}

$DB = mysql_select_db('login');

if(!$DB)
{
die("MySQL could not select Database!");
}

//STEP 2 Declare Variables

$Name = $_POST['email'];
$Pass = $_POST['password'];
$Query = mysql_query("SELECT * FROM Users WHERE Email='$Name' AND Password='$Pass'");
$NumRows = mysql_num_rows($Query);
$_SESSION['email'] = $Name;
$_SESSION['password'] = $Pass;

//STEP 3 Check to See If User Entered All Of The Information

if(empty($_SESSION['email']) || empty($_SESSION['password']))
{
die("Go back and login before you visit this page!");
}

if($Name && $Pass == "")
{
die("Please enter in a email and password!");
}

if($Name == "")
{
die("Please enter your email!" . "</br>");
}

if($Pass == "")
{
die("Please enter a password!");
echo "</br>";
}

//STEP 4 Check Username And Password With The MySQL Database

if($NumRows != 0)
{
while($Row = mysql_fetch_assoc($Query))
{
$Database_Name = $Row['email'];
$Database_Pass = $Row['password'];
}
}
else
{
die("Incorrect Email or Password!");
}

if($Name == $Database_Name && $Pass == $Database_Pass)
{
// If The User Makes It Here Then That Means He Logged In Successfully
header ("Location: http://localhost/Login%20Page/main.html");
exit();
}

?>
